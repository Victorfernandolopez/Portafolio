# Instrucciones para ejecutar la prueba técnica

Hola,

A continuación se detallan los pasos para ejecutar la prueba técnica entregada.

## 📁 Estructura del proyecto

Este archivo ZIP contiene los siguientes directorios:

backend/ → Código del backend en FastAPI
frontend/ → Código fuente del frontend en Svelte
data.json → Archivo con los datos que se visualizan
Dockerfile → Imagen multi-stage
docker-compose.yml → Orquestador del entorno
README_ENTREGA.md → Este archivo


## 🧪 Requisitos

- Tener instalado [Docker Desktop](https://www.docker.com/products/docker-desktop)
- Tener habilitada la virtualización y WSL2 si usás Windows

## ▶️ Cómo ejecutar la aplicación

1. Descomprimir el archivo `.zip` entregado.
2. Abrir una terminal en la carpeta `prueva_tecnica`.
3. Ejecutar:

```bash
docker-compose up           # Siguientes veces
docker-compose down         # Para detenerlo
docker-compose up --build #si se cambia codigo o dependencias
```
## Acceder a las siguientes URLs:
Frontend: http://localhost:8000
Endpoint de datos: http://localhost:8000/data


